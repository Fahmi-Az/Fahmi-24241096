# input user

# data input dari user
data = input("masukan data : ")
print("data : ", data, "type = ", type(data))

# jika data adalah angka lakukan casting
angka = float (input("masukan angka : "))
print("data : ", angka, " type = ", type(angka))

# bagaimana jika data adalah boolean?

