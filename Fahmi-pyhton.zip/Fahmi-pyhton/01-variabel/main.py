# Variabel adalah tempat menampung data
# Menampung data / assignment data
a = 10 # Variabel a menamoung nilai 10
x = 5 # Variabel x menampung nilai 5 
panjang = 1000 # Variabel panjang menampung nilai 1000
# Memanggil data dalam variabel
print("nilai a = ", a)
print("nilai x = ", x)
print("nilai panjang = ", panjang)
# penamaan variabel
nilai_y = 15 # ini boleh
juta10 = 10000000  # boleh juga
namaDepan = "Mizii" # sudah jelas boleh

a = 7
print("nilai a = ", a)
b = a
print("nilai b = ", b)
a = nilai_y
print("nilai a = ", a)
b = a
print("nilai b = ", b)