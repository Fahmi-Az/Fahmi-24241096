print("HELLO WORLD")

nama = "Fahmi Aziz"
umur = 20
print("Nama:", nama)
print("Umur:", umur)

def sapa(pesan):
    print("Pesan:", pesan)

sapa("-Wellcome To My Domain Expansion-")