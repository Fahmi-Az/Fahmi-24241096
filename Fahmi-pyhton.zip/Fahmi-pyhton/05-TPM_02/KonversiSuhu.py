# Input suhu dalam Fahrenheit
fahrenheit = float(input("Masukkan suhu dalam Fahrenheit: "))

# Konversi ke Celsius
celsius = (5/9) * (fahrenheit - 32)

# Tampilkan hasilnya
print(f"{fahrenheit} Fahrenheit sama dengan {celsius} Celsius")

